import Descriptions from './src/Descriptions.vue'

export type { DescriptionsSchema } from './src/types'

export { Descriptions }
