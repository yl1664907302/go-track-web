import Breadcrumb from './src/Breadcrumb.vue'

export { Breadcrumb }
