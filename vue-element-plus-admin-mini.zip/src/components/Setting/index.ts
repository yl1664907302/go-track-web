import Setting from './src/Setting.vue'

export { Setting }
