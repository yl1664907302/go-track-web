import BaseButton from './src/Button.vue'

export { BaseButton }
