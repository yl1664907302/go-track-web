import 'virtual:svg-icons-register'
