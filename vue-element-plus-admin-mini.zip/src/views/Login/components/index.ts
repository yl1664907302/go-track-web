import LoginForm from './LoginForm.vue'
import RegisterForm from './RegisterForm.vue'

export { LoginForm, RegisterForm }
